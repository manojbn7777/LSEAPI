﻿using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using LondonStockAPI.Services.Interfaces;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using System.Diagnostics;
using System.Globalization;

namespace LondonStockAPI.Controllers
{
    
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [EnableCors("LimitedCORS")]
    [EnableRateLimiting("TradesPolicy")] // Apply rate limit here
    public class TradesController : ControllerBase
    {
        private readonly ITradeCommandService _commandService;
        private readonly ITradeQueryService _queryService;
        private readonly ILogger<TradesController> _logger;

        public TradesController(ITradeCommandService commandService, ITradeQueryService queryService, ILogger<TradesController> logger)
        {
            _commandService = commandService;
            _queryService = queryService;
            _logger = logger;
        }

        [HttpPost]
        public async Task<IActionResult> AddTrade([FromBody] TradeDTO dto)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();

                return BadRequest(new ApiResponse<IEnumerable<string>>(
                    false,
                    "Validation failed",
                    errors
                ));
            }

            using (_logger.BeginScope("CorrelationId: {CorrelationId}", Guid.NewGuid()))
            {
                _logger.LogInformation("Received request to add trade for {Symbol}", dto.TickerSymbol);

                try
                {
                    var stopwatch = Stopwatch.StartNew();
                    var trade = await _commandService.AddTradeAsync(dto);
                    stopwatch.Stop();

                    _logger.LogInformation("Trade successfully added with ID {TradeId} in {Elapsed} ms", trade.Id, stopwatch.ElapsedMilliseconds);

                    return CreatedAtAction(nameof(GetAllTrades), new { id = trade.Id },
                        new ApiResponse<Trade>(true, "Trade created successfully", trade));
                }
                catch (InvalidOperationException ex)
                {
                    _logger.LogWarning(ex, "Invalid operation while adding trade for {Symbol}", dto.TickerSymbol);
                    return BadRequest(new ApiResponse<string>(false, ex.Message));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Unexpected error while adding trade for {Symbol}", dto.TickerSymbol);
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        new ApiResponse<string>(false, "An unexpected error occurred while adding the trade."));
                }
            }
        }

        [HttpGet]
        [EnableCors("LimitedCORS")]
        [EnableRateLimiting("TradesPolicy")]
        public async Task<IActionResult> GetAllTrades()
        {
            using (_logger.BeginScope("CorrelationId: {CorrelationId}", Guid.NewGuid()))
            {
                _logger.LogInformation("Fetching all trades");
                var stopwatch = Stopwatch.StartNew();
                var stockValues = await _queryService.GetAllTradesAsync();
                stopwatch.Stop();

                _logger.LogInformation("Retrieved {Count} trades in {Elapsed} ms", stockValues.Count, stopwatch.ElapsedMilliseconds);
                return Ok(new ApiResponse<object>(true, "Stock values retrieved", stockValues));
            }
        }

        [HttpGet("{ticker}")]
        public async Task<IActionResult> GetAveragePrice(string ticker)
        {
            using (_logger.BeginScope("CorrelationId: {CorrelationId}", Guid.NewGuid()))
            {
                _logger.LogInformation("Fetching average price for {Ticker}", ticker);
                var avgPrice = await _queryService.GetAveragePriceAsync(ticker);

                if (avgPrice == null || avgPrice == 0)
                {
                    _logger.LogWarning("No trades found for ticker {Ticker}", ticker);
                    return NotFound(new ApiResponse<string>(false, $"No trades found for ticker {ticker}"));
                }

                var stockData = new
                {
                    Ticker = ticker,
                    AveragePrice = string.Format(new CultureInfo("en-GB"), "{0:C}", avgPrice),
                    Currency = "GBP"
                };

                _logger.LogInformation("Average price for {Ticker} retrieved successfully", ticker);
                return Ok(new ApiResponse<object>(true, "Stock value retrieved", stockData));
            }
        }

        [HttpPost("range")]
        public async Task<IActionResult> GetStockValuesForList([FromBody] List<string> tickers)
        {
            using (_logger.BeginScope("CorrelationId: {CorrelationId}", Guid.NewGuid()))
            {
                _logger.LogInformation("Fetching stock values for {Count} tickers", tickers.Count);
                var values = await _queryService.GetStockValuesForListAsync(tickers);
                _logger.LogInformation("Retrieved stock values for {Count} tickers", values.Count());

                return Ok(new ApiResponse<IEnumerable<object>>(true, "Stock values retrieved", values));
            }
        }
    }
}