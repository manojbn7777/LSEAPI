﻿namespace LondonStockAPI.DTO
{
    public class StocksAllDTO
    {

        public string? TickerSymbol { get; set; }
        public decimal Price { get; set; }

        public decimal Quantity { get; set; }

        public int BrokerId { get; set; }
    }
}
