﻿using LondonStockAPI.Attributes;
using System.ComponentModel.DataAnnotations;

namespace LondonStockAPI.DTO
{
    public class TradeDTO
    {
        [Required(ErrorMessage = "TickerSymbol is required")]
        [MinLength(3, ErrorMessage = "TickerSymbol cannot be empty and with MinLength of 3 Characters")]
        public string? TickerSymbol { get; set; }

        
        [Required(ErrorMessage = "Price is required")]
        [GreaterThanZero]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Quantity is required")]
        [GreaterThanZero]
        public decimal Quantity { get; set; }

        [Required]
        public int BrokerId { get; set; }
    }
}
