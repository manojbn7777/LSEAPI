﻿using LondonStockAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace LondonStockAPI.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options) { }

        public DbSet<Trade> Trades => Set<Trade>();
        public DbSet<Broker> Broker => Set<Broker>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Trade>()
                .Property(t => t.Price)
                .HasPrecision(18, 4);

            modelBuilder.Entity<Trade>()
                .Property(t => t.Quantity)
                .HasPrecision(18, 4);

            //modelBuilder.Entity<Broker>()
            //.HasKey(b => b.BrokerId);

            //modelBuilder.Entity<Trade>()
            //    .HasOne(t => t.Broker)
            //    .WithMany(b => b.Trades)
            //    .HasForeignKey(t => t.BrokerId);
        }
    }
}
