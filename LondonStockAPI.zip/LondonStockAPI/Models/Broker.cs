﻿using LondonStockAPI.Models;

public class Broker
{
    public int BrokerId { get; set; }
    public string Name { get; set; } = string.Empty;

    //public ICollection<Trade> Trades { get; set; } = new List<Trade>();
}