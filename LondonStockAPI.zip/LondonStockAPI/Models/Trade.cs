﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LondonStockAPI.Models
{
    public class Trade
    {
        public int Id { get; set; }

        
        [MaxLength(10)]
        [Required]
        public string TickerSymbol { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal Price { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal Quantity { get; set; }

        [Required]
        public int BrokerId { get; set; }

        public DateTime TradeTime { get; set; } = DateTime.UtcNow;

        //public int BrokerId { get; set; }
        public Broker Broker { get; set; } = null!;
    }
}
