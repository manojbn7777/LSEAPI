using LondonStockAPI.Data;
using LondonStockAPI.Middleware;
using LondonStockAPI.Models;
using LondonStockAPI.Services;
using LondonStockAPI.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Serilog;
using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Serilog Enrichment
Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .Enrich.WithMachineName()
    .Enrich.WithEnvironmentName()
    .WriteTo.Console()
    .WriteTo.File("logs/log.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Host.UseSerilog();

builder.Services.AddControllers(options =>
{
    //options.Filters.Add<ValidationFilter>();
});
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    //options.SuppressModelStateInvalidFilter = true;
    options.InvalidModelStateResponseFactory = context =>
    {
        var errors = context.ModelState.Values
            .SelectMany(v => v.Errors)
            .Select(e => string.IsNullOrEmpty(e.ErrorMessage) ? e.Exception?.Message : e.ErrorMessage)
            .ToList();

        return new BadRequestObjectResult(new ApiResponse<IEnumerable<string>>(
            false,
            "Invalid request payload",
            errors
        ));
    };
});
var allowedOrigins = new[] { "*" };// https://LSEAPIclient.com

builder.Services.AddCors(options =>
{
    options.AddPolicy("LimitedCORS", policy =>
    {
        policy.WithOrigins(allowedOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Add Rate Limiting
builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("TradesPolicy", opt =>
    {
        opt.PermitLimit = 100; // Max 5 requests
        opt.Window = TimeSpan.FromSeconds(1); // Per 10 seconds
        opt.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
        opt.QueueLimit = 50; // Allow 2 queued requests
    });
});

//Register API Versioning
builder.Services.AddApiVersioning(options =>
{
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.DefaultApiVersion = new ApiVersion(1, 0);
    options.ReportApiVersions = true;
});

//Swagger with versioning:
builder.Services.AddVersionedApiExplorer(options =>
{
    options.GroupNameFormat = "'v'VVV";
    options.SubstituteApiVersionInUrl = true;
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AppDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddHealthChecks();
builder.Services.AddDistributedMemoryCache();

builder.Services.AddScoped<ITradeCommandService, TradeCommandService>();
builder.Services.AddScoped<ITradeQueryService, TradeQueryService>();
var app = builder.Build();
app.UseCors("LimitedCORS");
app.UseRateLimiter(); // Enable rate limiting middleware
app.UseMiddleware<ExceptionMiddleware>();
app.MapHealthChecks("/health");
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
//Handling JSON Parsing Errors Globally
app.Use(async (context, next) =>
{
    try
    {
        await next();
    }
    catch (JsonException ex)
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
        await context.Response.WriteAsJsonAsync(new ApiResponse<string>(
            false,
            "Invalid JSON format",
            ex.Message
        ));
    }
});
app.UseHttpsRedirection();
app.MapControllers();

app.Run();