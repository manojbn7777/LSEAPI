﻿using LondonStockAPI.DTO;
using LondonStockAPI.Models;

namespace LondonStockAPI.Services.Interfaces
{
    public interface ITradeQueryService
    {
        Task<decimal?> GetAveragePriceAsync(string symbol);
        //Task<List<Trade>> GetAllTradesAsync();
        Task<List<StocksAllDTO>> GetAllTradesAsync();
        //Task<List<Trade>> GetPagedTradesAsync(int pageNumber, int pageSize);
        Task<IEnumerable<object>> GetStockValuesForListAsync(List<string> tickers);
    }
}
