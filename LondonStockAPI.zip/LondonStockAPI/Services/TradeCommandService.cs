﻿using LondonStockAPI.Data;
using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using LondonStockAPI.Services.Interfaces;
using System.Diagnostics;

namespace LondonStockAPI.Services
{
    public class TradeCommandService : ITradeCommandService
    {
        private readonly AppDBContext _context;
        private readonly ILogger<TradeCommandService> _logger;

        public TradeCommandService(AppDBContext context, ILogger<TradeCommandService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<Trade> AddTradeAsync(TradeDTO dto)
        {
            var stopwatch = Stopwatch.StartNew();
            _logger.LogInformation("Attempting to add trade for {Symbol} at {Price}", dto.TickerSymbol, dto.Price);

            var broker = await _context.Broker.FindAsync(dto.BrokerId);
            if (broker == null)
            {
                _logger.LogWarning("Broker with ID {BrokerId} not found", dto.BrokerId);
                throw new InvalidOperationException($"Broker with ID {dto.BrokerId} does not exist.");
            }

            var trade = new Trade
            {
                TickerSymbol = dto.TickerSymbol ?? string.Empty,
                Quantity = dto.Quantity,
                Price = dto.Price,
                BrokerId = dto.BrokerId
            };

            _context.Trades.Add(trade);
            await _context.SaveChangesAsync();

            stopwatch.Stop();
            _logger.LogInformation("Trade for {Symbol} added successfully with ID {TradeId} in {Elapsed} ms", trade.TickerSymbol, trade.Id, stopwatch.ElapsedMilliseconds);
            return trade;
        }
    }
}