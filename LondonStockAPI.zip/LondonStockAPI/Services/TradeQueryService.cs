﻿using LondonStockAPI.Data;
using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using LondonStockAPI.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System.Globalization;
using System.Diagnostics;
using System.Text.Json;

public class TradeQueryService : ITradeQueryService
{
    private readonly AppDBContext _context;
    private readonly IDistributedCache _cache;
    private readonly ILogger<TradeQueryService> _logger;

    public TradeQueryService(AppDBContext context, IDistributedCache cache, ILogger<TradeQueryService> logger)
    {
        _context = context;
        _cache = cache;
        _logger = logger;
    }

    public async Task<List<StocksAllDTO>> GetAllTradesAsync()
    {
        var stopwatch = Stopwatch.StartNew();
        var cached = await _cache.GetStringAsync("all_trades");
        if (cached != null)
        {
            _logger.LogInformation("Cache hit for all trades");
            return JsonSerializer.Deserialize<List<StocksAllDTO>>(cached);
        }

        _logger.LogInformation("Cache miss for all trades, querying database");
        var trades = await _context.Trades
            .AsNoTracking()
            .Select(g => new StocksAllDTO
            {
                TickerSymbol = g.TickerSymbol,
                Price = g.Price,
                Quantity = g.Quantity,
                BrokerId = g.BrokerId
            })
            .ToListAsync();

        await _cache.SetStringAsync("all_trades", JsonSerializer.Serialize(trades), new DistributedCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5)
        });

        stopwatch.Stop();
        _logger.LogInformation("Retrieved {Count} trades from database in {Elapsed} ms", trades.Count, stopwatch.ElapsedMilliseconds);
        return trades;
    }

    public async Task<decimal?> GetAveragePriceAsync(string symbol)
    {
        var stopwatch = Stopwatch.StartNew();
        _logger.LogInformation("Fetching average price for {Symbol}", symbol);

        var cached = await _cache.GetStringAsync($"avg:{symbol}");
        if (cached != null)
        {
            _logger.LogInformation("Cache hit for {Symbol}", symbol);
            return decimal.Parse(cached);
        }

        _logger.LogInformation("Cache miss for {Symbol}, querying database", symbol);
        var trades = await _context.Trades
            .AsNoTracking()
            .Where(t => t.TickerSymbol == symbol)
            .ToListAsync();

        if (!trades.Any())
        {
            _logger.LogWarning("No trades found for {Symbol}", symbol);
            return 0;
        }

        var avg = trades.Average(t => t.Price);
        await _cache.SetStringAsync($"avg:{symbol}", avg.ToString(), new DistributedCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10)
        });

        stopwatch.Stop();
        _logger.LogInformation("Average price for {Symbol} calculated as {Average} in {Elapsed} ms", symbol, avg, stopwatch.ElapsedMilliseconds);
        return avg;
    }
    public async Task<IEnumerable<object>> GetStockValuesForListAsync(List<string> tickers)
    {
        _logger.LogInformation("Fetching stock values for {Count} tickers", tickers.Count);

        var upperTickers = tickers.Select(t => t.ToUpper()).ToList();

        var result = await _context.Trades
            .Where(t => upperTickers.Contains(t.TickerSymbol))
            .GroupBy(t => t.TickerSymbol)
            .Select(g => new StockValueDTO
            {
                Ticker = g.Key,
                AveragePrice = string.Format(new CultureInfo("en-GB"), "{0:C}", g.Average(t => t.Price)),
                Currency = "GBP"
            })
            .ToListAsync();

        _logger.LogInformation("Retrieved stock values for {Count} tickers", result.Count);
        return result;
    }
}